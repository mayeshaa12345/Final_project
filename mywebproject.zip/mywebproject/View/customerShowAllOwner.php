<h1 align="center">Customer page</h1>

<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="customerdesign.css">
</head>

<body>
    <div class="menubar">
        <a href="customer.php">Home</a>

        <div class="menubar_content">
            <a href="#">My personal Information</a>
            <div class="menubar_subcontent">
                <a href="customerAboutMe.php">My details</a>
                <a href="customerChangePassword.php">Change my password</a>
            </div>
        </div>

        <div class="menubar_content2">
            <a href="#">Other user information</a>
            <div class="menubar_subcontent2">
                <a href="customerShowAllOwner.php">Show all owner</a>
                <a href="customerShowAllDriver.php">Show all driver</a>
                <a href="customerShowAllCustomer.php">Show all customer</a>
            </div>
        </div>

        <div class="menubar_content3">
            <a href="#">Car information</a>
            <div class="menubar_subcontent3">
                <a href="customerShowAllCar.php">Show all car</a>
            </div>
        </div>
        <a href="customerHelpline.php">Helpline</a>
        <a href="login.php">Logout</a>
    </div>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>





<?php
session_start();
echo "<h3 align='right' style='color:green;'>login as (" . $_SESSION['user'] . ") </h3>";
?>

<table align="center">
<td>
            <img src="2customer.PNG" alt="" height=200 width=300 />
        </td><br>
</table>

<table align="center">
    <tr>
        <th></th>
    </tr>
    <tr>
        <td>
            <?php
            $count = 0;
            $owner_count = 1;

            $current_data = file_get_contents('../Model/userdata.json');
            $array_data = json_decode($current_data, false);

            foreach ($array_data as $b) {
                if ($b->role == "Owner") {
                    echo '<b>Owner No. </b>' . $owner_count . "," . "<br>";
                    echo "Username: " . $b->name . "<br>";
                    echo "Gender : " . $b->gender . "<br>";
                    echo "Role : " .  $b->role . "<br>";
                    echo "I have : " . $b->have . "<br>";
                    echo "Address : " . $b->address . "<br>";
                    "<br>";
                    "<br>";
                    $owner_count += 1;
                    $count += 1;
                } else {
                    $count += 1;
                }
            }
            ?>

        </td>
    </tr>
</table>