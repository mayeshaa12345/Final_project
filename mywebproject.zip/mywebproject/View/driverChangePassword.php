<h1 align="center">Driver page</h1>

<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="driverDesign.css">
</head>

<body>
    <div class="menubar">
        <a href="driver.php">Home</a>

        <div class="menubar_content">
            <a href="#">My personal Information</a>
            <div class="menubar_subcontent">
                <a href="driverAboutMe.php">My details</a>
                <a href="driverChangePassword.php">Change my password</a>
            </div>
        </div>

        <div class="menubar_content2">
            <a href="#">Other user information</a>
            <div class="menubar_subcontent2">
                <a href="driverShowAllCustomer.php">Show all customer</a>
                <a href="driverShowAlldriver.php">Show all driver</a>
                <a href="driverShowAllOwner.php">Show all owner</a>
            </div>
        </div>

        <div class="menubar_content3">
            <a href="#">All car information</a>
            <div class="menubar_subcontent3">
                <a href="driverShowAllCar.php">Show all car</a>
            </div>
        </div>
        <a href="driverDeclareSlot.php">Declare slot</a>
        <a href="driverHelpline.php">Helpline</a>
        <a href="login.php">Logout</a>
    </div>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>



<?php include '../Controller/changePasswordC.php'; ?>

<table class="driverChangePassword">

    <tr>

        <td>
            <br><br><br>
            <h3><u>Change Driver Password:</u></h3><br>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                Enter new password:
                <div class="form-control">
                    <input type="password" name="name_pass">
                </div>
                <br><br>
                <input class="buttonMain1" style="display:block; margin: 0 auto;" type="submit" name="dpchange" value="Change password">
            </form>
        </td>

    </tr>
</table>