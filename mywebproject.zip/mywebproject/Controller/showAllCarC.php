<head>
	<style>
		.dataTable {
			/*background-color:#989599;*/
			display: flex;
			align-items: center;
			justify-content: center;
		}
	</style>
</head>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vehicle_rental_application";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection not found:" . $conn->connect_error);
} else {
	$q = "SELECT * from all_car";
	$result = $conn->query($q);
	$output = '<br><br><br><table class="dataTable" border="1" width=100%><tr><th>Car name</th><th>Model</th><th>Per day rent</th><th>Contact No.</th></tr>';
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$output .= "<tr><td>{$row["name"]}</td><td>{$row["model"]}</td><td>{$row["price"]}</td><td>{$row["phone"]}</td></tr>";
		}
		$output .= '</table>';
	} else
		echo "Not a single data found";
}
$conn->close();
echo $output;
?>