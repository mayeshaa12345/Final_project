



<?Php
$f = 0;
if (isset($_POST['changeClick'])) {

    $current_data = file_get_contents('../Model/userdata.json');
    $array_data = json_decode($current_data, false);

    $f = 0;
    foreach ($array_data as $b) {
        if ($b->name == $boxnameold) {
            $f = 1;
            break;
        }
        $count += 1;
    }

    if ($f == 1) {
        $current_data = file_get_contents('../Model/userdata.json');
        $array_data = json_decode($current_data, true);
        $array_data[$count]['role'] = $role;
        $array_data[$count]['name'] = $boxnamenew;
        $final_data = json_encode($array_data);
        file_put_contents('../Model/userdata.json', $final_data);
        echo "<h3 align='center' style='color:green;'> <b> Data Updated! </b> </h3>";
    } else {
        echo "<h3 align='center' style='color:red;'> <b>User not found!.</b> </h3>";
    }
}

?>