


<?Php
if (isset($_POST['deleteClick'])) {
    $current_data = file_get_contents('../Model/userdata.json');
    $array_data = json_decode($current_data, true);
    unset($array_data[$count]);
    $final_data = json_encode($array_data);
    file_put_contents('../Model/userdata.json', $final_data);
    echo "<h3 align='center' style='color:red;'> <b>Account deleted!.</b> </h3>";
    $click = 0;
}
?>